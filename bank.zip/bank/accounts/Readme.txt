Admin: admin_login.php
username:admin
password:password123

Users:
user:ross
password:password

user:racheal
password:password

user:joey
password:password

http://freeproject24.com/php-free-project-download/