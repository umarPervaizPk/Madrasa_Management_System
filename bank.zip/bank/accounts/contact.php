<?php
    include "header.php";
    include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="contact_style.css">
</head>

<body>
    <div class="flex-container-background">
        <div class="flex-container-heading">
            <h1 id="contact">ادارہ</h1>
        </div>

        <div class="flex-container" style="border-bottom: 0;
                                           border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">
            <div class="flex-item">

                    <h1 style="text-align:center;">جامعہ رحمانیہ</h1>
                  
                   
                </p>
            </div>
           
        </div>
    </div>

</body>
</html>
