﻿<?php require_once('../classes/classes.php');
require_once('../includes/configuration.php');
$crud = new CRUD(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>قواعد و ضوابط برائے پرنٹ </title>
  <!--link rel="stylesheet" type="text/css" href="../css/default.css"/ -->
  <style>
    td {
      vertical-align: top;
    }
  </style>
</head>

<body style="background-image:none; background-color:#ffffff;">
  <center>
    <div id="printerArea" style="width:1020px; font-family:'Jameel Noori Nastaleeq';  direction:rtl !important; font-size:35px !important; background-color:#ffffff;" title="رپورٹ">
      <table width="800" align="center" border="1" cellspacing="0" cellpadding="4">
        </tr>
        <tr>
          <td style="text-align:justify !important;">
            <div id="contentTitle" style="text-align:justify;">
              <div style="text-align:center;">
                <font style="font-size:27px;">
                  <span style="padding:0 0 0 10px;"><?php echo (M_Name); ?> </span>
                  <span style="padding:0 0 0 10px;"><?php echo (M_Address); ?> </span>
                  <span style="padding:0 0 0 10px;"> فون </span> <?php echo (P_Number); ?>
                </font>
              </div>
              <div style="height:15px;">&nbsp;</div>
            </div>
            <table width="1020" id="rules" cellspacing="0" cellpadding="3" border="0" style="font-size:23px;">
              <tr>
                <td width="54">۱)</td>
                <td>
                 ہر طالب علم کو کتاب اللہ اور سنتِ نبوی کے تحت رہنا ہوگا۔ مثلاً لباس،وضع قطع ، اخلاقیات ہر ایک شریعت کے مطابق رکھنا ہو گا 
                </td>
              </tr>
              <tr>
                <td>۲) </td>
                <td>
                  تمام اوقات تعلیم ، تکرار ، مطالعہ کی پابندی لازمی ہو گی
                </td>
              </tr>
              <tr>
                <td>۳) </td>
                <td>
             نماز پنجگانہ تکبیر تحریمہ ساتھ ادا کرنی ہوگی ، جمعتہ المبارک کی شام حاضر ہونا لازم ہے ،
                </td>
              </tr>
              <tr>
                <td>۴) </td>
                <td>
         وقتاً فو وقتاً دی جانی والی ہدایات پر عمل کرنا ضروری ہوگا
                </td>
              </tr>
              <tr>
                <td>۵)</td>
                <td>
                 مدرسہ ہذا کی حدود میں شرعا ممنوعہ کوئی چیز یا ملکی قوانین کے خلاف کوئی چیز اور وہ چیز جو خرافات کے زمرے میں آتی ہو اور خلاف شریعت ہو اسکی سے اجتناب کریں 
                </td>
              </tr>
              <tr>
                <td>۶)</td>
                <td>
              ططلباء کو کسی بھی طرح کی گروہی،لسانی و علاقائی پارٹی بازی کرنے یا کسی ایسی تنظیم میں کام کرنے کی ہرگز اجازت نہیں ہوگی جو مذکورہ ہدف پر قائم ہو 
                </td>
              </tr>
              <tr>
                <td>۷)</td>
                <td>
              کسی بھی قسم کی سیاسی مذہبی مظاہروں میں شرکت کی اجازت نہیں ہوگی
                </td>
              </tr>
              <tr>
                <td>۸)</td>
                <td>
                  طالب علم انتظامیہ مدرسہ اپنی استطاعت کے مطابق جو  قیام و طعام پیش کریں اس پر اعتراض نہیں کیا جاسکتا ۔ کسی قسم کا فساد یا مطالبات اپنی طرف سے اجتماعی طور پر تمام کے تمام ممنوع ہیں
                </td>
              </tr>
              <tr>
                <td>۹) </td>
                <td>
               مدرسہ یا اساتذہ میں سے کسی کے خلاف یا انتظامیہ مدرسہ کے خلاف کسی بھی قسم کی چہ مگویاں ناقابل معافی جرم ہے۔
                </td>
              </tr>
              <tr>
                <td>۱۰)</td>
                <td>
                بغیر اطلاع تین دن سے زیادہ چھٹی کرنے پر جامعہ سے خارج کر دیا جائے گا
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <br />
    </div>
  </center>
</body>

</html>