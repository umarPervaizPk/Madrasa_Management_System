<table width="1100" border="0" cellspacing="0" cellpadding="4" height="43" align="center">
<tr>
	<td align="center"> <a href="?cmd=home" title="صفحہ اوّل"> صفحہ اول </a> </td>
	<td align="center"> <a href="?cmd=registrationForm" title="داخلہ فارم"> داخلہ فارم </a> </td>
    <td> <a href="?cmd=registrationUpdateForm" title=" ر جسٹریشن فارم میں تبدیلی کرنے کے لئے یہاں پر کلک کریں">داخلہ فارم تبدیلی </a></td>
    <td align="center"> <a href="?cmd=idCardStd" title="طالب العلم کارڈ"> طالب العلم کارڈ </a> </td>
    <td align="center"> <a href="?cmd=resultFrm" title="رزلٹ کا اندراج کیجیے"> رزلٹ بنائیے </a> </td>    
    <td align="center"> <a href="?cmd=attendenceSheet" title="کشف الحضور"> کشف الحضور</a> </td>
    <td align="center"> <a href="?cmd=stdPromotion" title="کسی بھی طالب العلم کا درجہ یا رول نمبر تبدیل کرنے کے لئے یہاں پر کلک کریں"> ترقی طالب علم </a> </td>        
    <td align="center"><a href="pages/addNewDarja.php?TB_iframe=true&height=250&width=600" class="thickbox" title="نیا درجہ یہاں سے درج کریں"> نیا درجہ </a> </td>
    <td align="center"><a href="pages/deleteDarja.php?TB_iframe=true&height=300&width=600" class="thickbox" title="درجہ کو یہاں سے مٹائیں "> درجہ مٹائیں </a> </td>
    <td align="center"><a href="pages/addSubjects.php?TB_iframe=true&height=300&width=600" class="thickbox" title="درجات میں مضامین محفوظ کریں"> اندراج مضامین </a></td>   
    <td align="center"><a href="pages/deleteSubject.php?TB_iframe=true&height=300&width=600" class="thickbox" title="مضامین کو یہاں سے مٹائیں"> مضامین مٹائیں </a></td>
	<td align="center"><a href="pages/changePassword.php?&KeepThis=true&TB_iframe=true&height=450&width=600" class="thickbox" title="پاس ورڈ تبدیل کریں"> پاس ورڈ تبدیلی </a></td>
	<td align="center"><a href="pages/editSubjects.php?&KeepThis=true&TB_iframe=true&height=450&width=600" class="thickbox" title="مضامین تبدیل کریں"> مضامین تبدیلی </a></td>
</tr>
</table>