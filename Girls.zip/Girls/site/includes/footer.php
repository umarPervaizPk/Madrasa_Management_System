<table border="0" cellspacing="2" id="footerLinks" cellpadding="4" width="100%">
<tr>
	<td colspan="6"><div class="rptDiv"><font> رپورٹس </font> </div></td>
</tr>
<tr>    
       <td width="18%" style="vertical-align:top; text-align:right;">
        <a href="Reports/resultQuarter.php" target="_blank" title="امتحان کا نتیجہ یہاں سے دیکھیں"> الگ الگ امتحان کا نتیجہ</a>
    </td>
    <td width="13%" style="vertical-align:top; text-align:right;">
        <a href="Reports/resultSheetByExamType.php" target="_blank" title="ہر امتحان کی ہر سال میں علحٰیدہ علحٰیدہ نتیجہ برائے علحٰیدہ طالب العلم دیکھیں"> رزلٹ شیٹ علحٰیدہ </a>
    </td>
    <td width="15%" style="vertical-align:top; text-align:right;">
        <a href="Reports/registeredStudentReport.php" target="_blank" title="ہر سال میں نئے داخل شدہ طالبات کی داخلہ فارم برائے پرنٹ کرنے کھولیں">  داخل شدہ طالبات </a>
    </td>
    <td width="14%" style="vertical-align:top; text-align:right;">
        <a href="?cmd=dmcFrm" title="ڈی ایم سی"> کشف الدرجات</a>
    </td>
    <td width="13%" style="vertical-align:top; text-align:right;">
        <a href="Reports/promotionDateEndDates.php" target="_blank" title="تاریخ داخلہ و تاریخ انتہاء کا مکمل لسٹ یہاں سے دیکھیں"> تاریخ داخلہ و انتہاء </a>
    </td>
     <td width="15%" style="vertical-align:top; text-align:right;"><a href="?cmd=search" title="طالب العلم کو تلاش کریں"> تلاش کیجیے</a></td>
</tr>
<tr>
	<td colspan="6">&nbsp;</td>
</tr>
<tr>
	<td style="vertical-align:top; text-align:right;"><a href="Reports/attendanceReport.php" title="رجسٹر روزانہ حاضری" target="_new">حاضری </a></td>
    <td style="vertical-align:top; text-align:right;"> <a href="Reports/stdList.php" title="طالبات کی مکمل لِسٹ یہاں پر دیکھیں" target="_new"> کل طالبات </a> </td>    
    <td style="vertical-align:top; text-align:right;"> <a href="Reports/admissionRegisterList.php" title="رجسٹر داخل / خارج " target="_new"> داخل/خارج </a> </td>
    <td style="vertical-align:top; text-align:right;"> <a href="Reports/nonLocalStdList.php" title="غیر رہائشی طالبات کا مکمل لسٹ" target="_new"> غیر رہائشی طالبات </a> </td>
    <td style="vertical-align:top; text-align:right;"> <a href="Reports/examMarksEmptyReport.php" target="_blank" title="نتاءیج الختبارات">خالی امتحانی لسِٹ</a> </td>    
    <td style="vertical-align:top; text-align:right;"> <a href="Reports/resultSheet.php" target="_new" title="رزلٹ شیٹ"> رزلٹ شیٹ</a> </td>
</tr>
<tr>
	<td colspan="6">&nbsp;</td>
</tr>
<tr>
	<td width="18%" style="vertical-align:top; text-align:right;">
       <a href="Reports/madrasaTermsConditions.php" target="_blank" title="قواعد و ضوابط پرنٹ کیجئے"> قواعد و ضوابط پرنٹ </a>  
    </td>
    <td style="vertical-align:top; text-align:right;"> <a href="http://www.UmarPervaiz.Pk" target="_blank" title="اگر کسی قسم کا کوئی سوال پوچھنا ہو تو یہاں پر کلک کریں"> مدد چاہیے؟ </a> </td>

     <td colspan="3" style="vertical-align:top; text-align:right;"> <a href="pages/logout.php" title="اپنے اکاونٹ کو لاک کر لیں"> پروگرام بند کریں </a> </td>
      <td colspan="3" style="vertical-align:top; text-align:right;"> <a href="https://accounts.jamiarahmania.org" title=""> اکاونٹ</a> </td>
	
     <td style="vertical-align:top; text-align:right;"> <a href="http://Boys.jamiarahmania.org" target="_blank" title=""> طلبا فارم </a> </td>
    
</tr>
</table>