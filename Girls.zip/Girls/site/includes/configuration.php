<?php 
define("M_Name","جامعہ رحمانیہ");//madrasa name
define("M_Address","چاندنی چوک بلاک بی استقلال آباد سرگودھا(پاکستان)");//madrasa address
define("L_Address","اندنی چوک بلاک بی استقلال آباد سرگودھا(پاکستان)");//long address
define("P_Number","0092-300-6031604");//phone number
define("Reg_Number","2/4875");//Elhaaq Number / Registration Number
define("Elhaq","05879"); //Elhaaq ur Raqam
define("Mohtamim","مہتمم صاحب کا نام");//Name of the Mohtamim
define("Phone","0092-333-6780766"); // Landline Phone Number
define("Cell"," 0092-300-6008805"); //Cell Phone Number
define("E_Address","Address for Student Card.<br />with phone . Tel: 0092-300-6007508");//Address English for id card
?>