﻿<!--[if IE 6]>
<style>
body {behavior: url("csshover3.htc");}
#menu li .drop {background:url("img/drop.gif") no-repeat right 8px; 
</style>
<![endif]-->

<ul id="menu">

    <li class="menu_right"><a href="?cmd=1" class="drop">صفحہ اول </a><!-- Begin 3 columns Item -->

        <div class="dropdown_3columns align_right">
            <!-- Begin 3 columns container -->


            <div class="col_1">

                <ul class="greybox">

                    <li><a href="?cmd=registrationForm" title="داخلہ فارم">
                            داخلہ فارم
                        </a></li>
                    <li><a href="#">Mac Apps</a></li>
                    <li><a href="#">Web Apps</a></li>
                </ul>

            </div>

            <div class="col_1">

                <ul class="greybox">
                    <li><a href="#">ThemeForest</a></li>
                    <li><a href="#">GraphicRiver</a></li>
                    <li><a href="#">ActiveDen</a></li>
                    <li><a href="#">VideoHive</a></li>
                    <li><a href="#">3DOcean</a></li>
                </ul>

            </div>

            <div class="col_1">

                <ul class="greybox">
                    <li><a href="#">Design</a></li>
                    <li><a href="#">Logo</a></li>
                    <li><a href="#">Flash</a></li>
                    <li><a href="#">Illustration</a></li>
                    <li><a href="#">More...</a></li>
                </ul>

            </div>


        </div><!-- End 3 columns container -->

    </li><!-- End 3 columns Item -->


</ul>