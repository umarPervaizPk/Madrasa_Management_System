<div id="errorPage">
<?php echo($crud->errorMsg("آپ جس پیج کو تلاش کر رہے ہے وہ پیج موجود نہیں ہے۔","غلطی")); ?><br />
<div style="padding:14px; font-size:30px;">
شائد اس پیج کو مکمل طور پر ہٹایا گیا ہے۔
</div>
</div>