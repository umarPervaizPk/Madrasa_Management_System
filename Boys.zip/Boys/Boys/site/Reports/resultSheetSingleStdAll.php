﻿<?php session_start();
require_once('../classes/classes.php'); ?>
<?php $crud = new CRUD();
require_once("../includes/configuration.php");
$darja = "";
$result = "";
$strSubject = "";
$colspan = 0;
$i = 0;
$sno = 0;
$strSubjectMrks = "";
$regSno = "";
$subjectMarksSql = "";
$resultMarks = "";
$subjectMarksSql1 = "";
$resultMarks1 = "";
$subjectMarksSql2 = "";
$resultMarks2 = "";
$totalMarksIn1 = 0;
$totalMarksIn2 = 0;
$totalMarksIn3 = 0;
$totalMarksInSubjects1 = 0;
$totalMarksInSubjects2 = 0;
$totalMarksInSubjects3 = 0;
$registrationNo = 0;
$mezaan1 = 0;
$mezaan2 = 0;
$mezaan3 = 0;
$v1 = 0;
$v2 = 0;
$v3 = 0;
$v4 = 0;
$v5 = 0;
$v6 = 0;
$v7 = 0;
$v8 = 0;
$v9 = 0;
$v_9 = 0;
$v10 = 0;
$v11 = 0;
$v12 = 0;
$v13 = 0;
$v14 = 0;
$v15 = 0;
$v16 = 0;
$v17 = 0;
$v18 = 0;
$v19 = 0;
$v20 = 0;
$v21 = 0;
$v22 = 0;
$v23 = 0;
$v24 = 0;
$v25 = 0;
$v26 = 0;
//it will hold the obtanied total marks per result by the student on the year bases
$obtMarksSum1 = 0;
$obtMarksSum2 = 0;
$obtMarksSum3 = 0;
$result1 = "";
$result2 = "";
$result3 = "";
$mrks1 = "";
$mrks2 = "";
$mrks3 = "";
$resultCounter = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>رزلٹ شیٹ برائے <?php if (isset($_REQUEST['darja'])) {
								echo ($crud->getValue("SELECT darja FROM darjaat WHERE derjaCode = " . $_REQUEST['darja'], "darja"));
							} ?></title>
	<link rel="stylesheet" type="text/css" href="../css/default.css" />
	<style>
		td {
			vertical-align: top;
			font-family: 'Jameel Noori Nastaleeq';
			line-height: 20px;
		}

		#singleStdAllResult a {
			font-size: 20px;
			color: #ffffff;
			text-decoration: none;
		}

		#singleStdAllResult a:hover {
			font-size: 20px;
			color: #ffffff;
			text-decoration: underline;
		}
	</style>
	<?php
	if (isset($_SESSION["hijri"]) && !empty($_SESSION["hijri"])) {
		$sessionDate = new DateTime($_SESSION["hijri"]);
		$sessionDate = $sessionDate->format('Y-m-d');
		$dtAry = explode("-", $sessionDate);
		$dateEnding = $dtAry[0] + 1;
		$dateEnding = $dateEnding . '-' . $dtAry[1] . '-' . $dtAry[2];
	}
	?>
	<link rel="stylesheet" type="text/css" href="../css/default.css" />
	<script type="text/javascript" src="../js/functions.js"></script>
	<script language="javascript" type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/jquery.datepick.js"></script>
	<style type="text/css">
		@import "../js/jquery.datepick.css";
	</style>
	<script type="text/javascript">
		$(document).ready(function() {
			$(function() {
				$('#promotionDate').datepick();
				$('#dateEnd').datepick();
			});
		});
		$(document).ready(function() {
			$("#hide").click(function() {
				$("#searchPanel").slideUp(1000);
			});
		});
		$(document).ready(function() {
			$("body").dblclick(function() {
				$("#searchPanel").slideDown(1000);
			});
		});
		$(document).ready(function() {
			$("#print").click(function() {
				Print("printerArea");
			});
		});
	</script>
</head>

<body style="background-image:none; background-color:#ffffff; direction:rtl" dir="rtl">
	<center>
		<div id="searchPanel" style="width:1117px; background-color:#CCC">
			<span id="msg"></span>
			<form method="post" action="resultSheetSingleStdAll.php" class="generalTextFonts">
				<table width="1117" align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="#006633" height="100">
					<tr>
						<td width="1117" style="text-align:center; vertical-align:middle; line-height:1px !important">
							<table align="center" border="0" cellpadding="0" cellspacing="0" style="font-size:20px;">
								<tr>
									<td width="67" style="vertical-align:middle; line-height:1px !important">
										<font color="#FFFFFF"> درجہ </font>
									</td>
									<td width="176" style="vertical-align:middle; line-height:1px !important">
										<?php $css = 'style="width:140px; height:40px; position:relative;top:1px;" onchange="fillComboStdAllWithDate($(\'#promotionDate\').val(),$(\'#dateEnd\').val(),this.value,\'stdCombo\');"';
										$crud->darjaatCmb('darja', $css); ?>
									</td>
									<td width="84" style="color:#ffffff;"> <span style="position:relative; top:10px;"> تاریخ ابتداء </span> </td>
									<td width="124">
										<input type="text" name="promotionDate" id="promotionDate" class="frmInputTxt" style="width:110px;" value="<?php if (isset($_REQUEST['promotionDate']) && !empty($_REQUEST['promotionDate'])) {
																																						echo ($_REQUEST['promotionDate']);
																																					} else {
																																						echo ($sessionDate);
																																					} ?>" />
									</td>
									<td width="73" style="color:#ffffff;"><span style="position:relative; top:10px;"> تاریخ انتہا </span> </td>
									<td width="130">
										<input type="text" name="dateEnd" id="dateEnd" class="frmInputTxt" style="width:110px;" value="<?php if (isset($_REQUEST['dateEnd']) && !empty($_REQUEST['dateEnd'])) {
																																			echo ($_REQUEST['dateEnd']);
																																		} else {
																																			echo ($dateEnding);
																																		} ?>" />
									</td>
									<td width="79" style="vertical-align:middle; line-height:1px !important">
										<font color="#FFFFFF"> طالب علم </font>
									</td>
									<td width="140" style="vertical-align:middle; line-height:1px !important">
										<span id="stdCombo">
											<select name="regSno" id="regSno" class="frmSelect" style="width:140px; height:40px; font-size:20px;">
												<option value=""> </option>
											</select>
										</span>
									</td>
									<td width="80" style="vertical-align:middle;"><input type="submit" name="btnSearch" id="btnSearch" value="تلاش کریں" class="btnSave" /></td>
									<td width="91" style="vertical-align:middle;"><span id="singleStdAllResult"> <a href="resultSheet.php" title="مکمل نتائج یہاں پر دیکھیں"> مکمل طلباء کا نتیجہ</a></span></td>
									<td width="63"> <a href="#" id="hide" onclick="return false;" title="سرچ پینل کو چھہائیں">
											<img src="../images/minus.png" style="border-width:0px;" />
										</a> </td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</form>
		</div>



		<div id="printerArea" style="width:1117px">
			<?php
			$sqlRstSearch = "";
			$regSno = "";
			$year = "";
			if (isset($_REQUEST['btnSearch'])) {
				if (
					isset($_REQUEST['darja']) && !empty($_REQUEST['darja']) &&
					isset($_REQUEST['promotionDate']) && !empty($_REQUEST['promotionDate']) &&
					isset($_REQUEST['dateEnd']) && !empty($_REQUEST['dateEnd']) &&
					isset($_REQUEST['regSno']) && !empty($_REQUEST['regSno'])
				) {
					$darja = addslashes($_REQUEST['darja']);
					//$darja=mysql_real_escape_string($darja);
					$promotionDate = addslashes($_REQUEST['promotionDate']);
					$dateEnd = addslashes($_REQUEST['dateEnd']);
					$regSno = addslashes($_REQUEST['regSno']);
					//check if the result is available on this year or not
					$sqlRstSearch = "SELECT * FROM result WHERE promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "' AND stdSno = " . $regSno . " AND darjaSno = " . $darja;
					//echo($sqlRstSearch);
					if ($crud->search($sqlRstSearch)) { ?>
						<table width="1117" border="0" align="center">
							<tr>
								<td width="364">
									<h2><?php echo (M_Name); ?></h2>
									<font style="font-size:20px;"><?php echo (L_Address); ?></font>
								</td>
								<td width="287" align="center">
									<h2>مکتب نتائج الاختبارات
										<hr style="border-style:solid; height:1px;" />
										المرحلۃ <?php if (isset($_REQUEST['darja'])) {
													echo ($crud->getValue("SELECT darja FROM darjaat WHERE derjaCode = " . $_REQUEST['darja'], "darja"));
												} ?> العامہ
									</h2>
								</td>
								<td width="452" style="text-align:center; vertical-align:middle; padding-right:100px;">
									<table width="400" border="1" cellspacing="0" cellpadding="3">
										<tr>
											<td style="text-align:right;"> <span style="padding:0 0 0 10px"> تاریخ اجراء </span> <input type="text" value="<?php echo ($crud->getValue("SELECT edu_year_remarks FROM result WHERE resultTerm = 1 AND promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "'", "edu_year_remarks")); ?>" id="ex1" style="width:320px; border:0px; padding:2px;" /></td>
										</tr>
										<tr>
											<td style="text-align:right;"> <span style="padding:0 0 0 10px"> تاریخ اجراء </span> <input type="text" value="<?php echo ($crud->getValue("SELECT edu_year_remarks FROM result WHERE resultTerm = 2 AND promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "'", "edu_year_remarks")); ?>" id="ex2" style="width:320px; border:0px; padding:2px;" /></td>
										</tr>
										<tr>
											<td style="text-align:right;"> <span style="padding:0 0 0 10px"> تاریخ اجراء </span> <input type="text" value="<?php echo ($crud->getValue("SELECT edu_year_remarks FROM result WHERE resultTerm = 3 AND promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "'", "edu_year_remarks")); ?>" id="ex3" style="width:320px; border:0px; padding:2px;" /></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>


						<table width="1117" border="1" align="center" cellspacing="0" cellpadding="0">
							<tr>
								<td width="19" style="vertical-align:middle; text-align:center;">
									<font size="3">الرقم</font>
								</td>
								<td width="46" nowrap="nowrap" style="vertical-align:middle; text-align:center;">
									<font size="3" style="font-family:'Jameel Noori Nastaleeq'; line-height:20px;">اسم طالب <br />مع ولدیت</font>
								</td>
								<td width="63" style="vertical-align:middle; text-align:center; font-weight:bold;">
									<font size="3">سالانہ<br /> نتائج</font>
								</td>
								<td width="248" style="vertical-align:middle; text-align:center; border-width:0px;">
									<table border="1" cellspacing="0" cellpadding="0" width="250">
										<?php   //to fetch all the subjects in the specified darja in table below
										$subjectSql = "SELECT sno,subjectName FROM subjects WHERE darjaSno = " . $darja;
										//$resultSubject = mysql_query($subjectSql,$crud->con);
										if ($crud->search($subjectSql)) {
											$subject_ary = array();
											foreach ($crud->getRecordSet($subjectSql) as $rowSubject) {
												//while($rowSubject = mysql_fetch_assoc($resultSubject)){ 
												$colspan += 1;
												$sbj = $rowSubject['subjectName'];
												$sbj = str_replace("/", "<br />", $sbj);
												$sbj = str_replace(",", "<br />", $sbj);
												$sbj = str_replace("،", "<br />", $sbj);
												$subject_ary[] = $rowSubject["sno"];
												$strSubject .= "<td style='width:50px;vertical-align:middle; text-align:center;'> " . $sbj . "</td>";
											}
										?>
											<tr>
												<td align="center" <?php if ($colspan > 1) {
																		echo (" colspan='" . $colspan . "'");
																	} ?>> مضامین </td>
											</tr>
											<tr>
												<?php echo ($strSubject); ?>
											</tr>
										<?php } //end if mysql_num_rows() 
										?>
									</table>
								</td>
								<td width="38" style="text-align:center; vertical-align:middle;">
									<font size="3">مجموع الدرجات</font>
								</td>
								<td width="41" style="text-align:center; vertical-align:middle;">
									<font size="3">الدرجات المحصلۃ</font>
								</td>
								<td width="38" style="text-align:center; vertical-align:middle;">
									<font size="3">الاوسط</font>
								</td>
								<td width="38" style="text-align:center; vertical-align:middle">
									<font size="3">التقدیر</font>
								</td>
								<!--<td width="40" style="text-align:center; vertical-align:middle;"><font size="3">الکیفیت</font></td>-->
								<td width="59" style="text-align:center; vertical-align:middle;">
									<font size="3">کشف الحضور</font>
								</td>
								<td width="349" style="border-width:0px;">
									<table width="351" border="1" cellspacing="0" cellpadding="0">
										<tr style="border-width:0px;">
											<td colspan="10" style="text-align:center"> ماہانہ حاضری <?php echo (($dateEnd) . ' - ' . $promotionDate); ?></td>
										</tr>
										<tr style="border-width:0px;">
											<td width="39" height="60" id="mont" style="vertical-align:middle; text-align:center;"> شوّال </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> ذو القعدة </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> ذو الحجّة </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> المحرّم </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> صفر </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> ربيع الأوّل </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> ربيع الثاني </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> جمادى الأول</td>
											<td width="39" style="vertical-align:middle; text-align:center;"> جمادى الثانية </td>
											<td width="39" style="vertical-align:middle; text-align:center;"> رجب </td>
										</tr>
									</table>
								</td>
								<td width="154" style="border-width:0px;">
									<table width="158" height="86" border="1" cellpadding="0" cellspacing="0">
										<tr style="border-width:0px;">
											<td colspan="2" style="text-align:center;"> سالانہ رپورٹ </td>
										</tr>
										<tr style="border-width:0px;">
											<td width="84" style="vertical-align:middle; text-align:center;"> میزان </td>
											<td width="68" style="vertical-align:middle; text-align:center;"> تصویر </td>
										</tr>
									</table>
								</td>
							</tr>

							<?php //loop over the data 
							?>
							<?php
							$resultAllSql = "SELECT DISTINCT
												  r.stdName, r.fatherName, r.sno
												FROM registrationInfo r,stdDarjaat st, result rs
												WHERE st.darja = " . $darja . " AND rs.darjaSno = " . $darja . " AND rs.promotionDate = '" . $promotionDate . "'
													 AND rs.dateEnd = '" . $dateEnd . "'
													 AND r.isActive = 1 AND st.stdSno = r.sno AND rs.stdSno = r.sno AND rs.stdSno = " . $regSno;
							//echo($resultAllSql);
							//exit();
							//$resultStd = mysql_query($resultAllSql,$crud->con);
							if ($crud->search($resultAllSql)) {
								foreach ($crud->getRecordSet($resultAllSql) as $rowsStd) {
									//while($rowsStd = mysql_fetch_assoc($resultStd)){
									$sno += 1;
									$regSno = $rowsStd['sno'];
							?>
									<tr>
										<td width="19">
											<font size="3"> <?php echo ($sno); ?> </font>
										</td>
										<td width="46">
											<font size="3" style="font-family:'Jameel Noori Nastaleeq'; line-height:17px;">
												<?php echo ($rowsStd['stdName'] . ' <strong> ولد </strong>' . $rowsStd['fatherName']); ?></font>
										</td>
										<td width="63" style="border-width:0px;">
											<table width="65" border="1" cellspacing="0" cellpadding="3">
												<tr style="border-width:0px;">
													<td align="right" class="session" style="font-size:17px; height:14px; line-height:13px;"> سہ ماہی </td>
												</tr>
												<tr style="border-width:0px;" class="session">
													<td align="right" style="font-size:17px; height:14px; line-height:13px;" class="session"> شش ماہی </td>
												</tr>
												<tr style="border-width:0px;" class="session">
													<td align="right" style="font-size:17px; height:14px; line-height:13px;"> سالانہ </td>
												</tr>
											</table>
										</td>
										<td style="border-width:0px;">
											<table width="250" border="1" cellpadding="0" cellspacing="0">
												<tr style="border-width:0px;">
													<?php   //to fetch all the subjects in the specified darja in table below
													$subjectMarksSql =     "SELECT r.obtmarks,regInfo.stdName,r.resultTerm,r.subjectSno,r.edu_year_remarks 
														FROM result r,regnumbers reg,registrationinfo regInfo
														WHERE r.darjaSno = " . $darja . " AND regInfo.sno = r.stdSno  
														AND regInfo.sno = reg.regSno AND r.resultTerm = 1 AND 
														regInfo.sno = " . $regSno . " AND regInfo.isActive = 1  
														AND r.promotionDate = '" . $promotionDate . "'
													 	AND r.dateEnd = '" . $dateEnd . "'";

													if ($crud->search($subjectMarksSql)) { //print_r($subjectMarksSql);
														$totalMarksInSubjects1 = 0;
														$totalMarksIn1 = 0;
														$mezaan1 = 0;
														$mezaan2 = 0;
														$mezaan3 = 0;
														$aryCounter = -1;
														foreach ($crud->getRecordSet($subjectMarksSql) as $rowSub) {
															$aryCounter += 1;
															//while($rowSub = mysql_fetch_array($resultMarks)){  
															$totalMarksIn1 += $rowSub['obtmarks'];
															$totalMarksInSubjects1 += $crud->getValue("SELECT s.totalMarks FROM subjects s WHERE s.sno = " . $rowSub['subjectSno'], "totalMarks");
															$sqlMarks = "SELECT obtmarks FROM result WHERE 
																				stdSno = '" . $regSno . "'
																				AND	darjaSno = " . $darja . " 
																				AND subjectsno = '" . $subject_ary[$aryCounter] . "'
																				AND resultTerm = 1 
																				AND promotionDate = '" . $promotionDate . "'
													 							AND dateEnd = '" . $dateEnd . "'";
															$obtN = $crud->getValue($sqlMarks, "obtmarks");
													?>
															<td width="246" style="width:80px; vertical-align:middle; text-align:center; <?php if ($rowSub['obtmarks'] < 40) { ?> background-color:#CACACA; font-weight:bold; font-size:13px; <?php } ?>">
																<?php echo ($obtN); ?>
															</td>
													<?php } //end while loop
													} //end if mysql_num_rows() 
													?>
												</tr>
												<tr style="border-width:0px;"><?php   //to fetch all the subjects in the specified darja in table below							   
																				$subjectMarksSql1 =     "SELECT r.obtmarks,regInfo.stdName,r.resultTerm,r.subjectSno,r.edu_year_remarks 
														FROM result r,regnumbers reg,registrationinfo regInfo
														WHERE r.darjaSno = " . $darja . " AND regInfo.sno = r.stdSno  
														AND regInfo.sno = reg.regSno AND r.resultTerm = 2 AND 
														regInfo.sno = " . $regSno . " AND regInfo.isActive = 1  
														AND r.promotionDate = '" . $promotionDate . "'
													 	AND r.dateEnd = '" . $dateEnd . "'";


																				if ($crud->search($subjectMarksSql1)) { //print_r($subjectMarksSql1);
																					$totalMarksInSubjects2 = 0;
																					$totalMarksIn2 = 0;
																					$aryCounter1 = -1;
																					foreach ($crud->getRecordSet($subjectMarksSql1) as $rowSub1) {
																						$aryCounter1 += 1;
																						//while($rowSub1 = mysql_fetch_assoc($resultMarks1)){ 
																						$totalMarksIn2 += $rowSub1['obtmarks'];
																						$totalMarksInSubjects2 += $crud->getValue("SELECT s.totalMarks FROM subjects s WHERE s.sno = " . $rowSub1['subjectSno'], "totalMarks");
																						$sqlMarks2 = "SELECT obtmarks FROM result WHERE 
															stdSno = '" . $regSno . "'
															AND	darjaSno = " . $darja . " 
															AND subjectsno = '" . $subject_ary[$aryCounter1] . "'
															AND resultTerm = 2 
															AND promotionDate = '" . $promotionDate . "'
															AND dateEnd = '" . $dateEnd . "'";
																						$obtN2 = $crud->getValue($sqlMarks2, "obtmarks");
																				?>
															<td style="vertical-align:middle; text-align:center; <?php if ($obtN2 < 40) { ?> background-color:#CACACA; font-weight:bold; font-size:13px; <?php } ?>""> 
										<?php echo ($obtN2); ?> </td>
                                        <?php } //end while loop
																				} //end if mysql_num_rows() 
										?>
                          </tr> 
                                <tr style=" border-width:0px;"><?php   //to fetch all the subjects in the specified darja in table below							   
																$subjectMarksSql2 =     "SELECT r.obtmarks,regInfo.stdName,r.resultTerm,r.subjectSno,r.edu_year_remarks 
														FROM result r,regnumbers reg,registrationinfo regInfo
														WHERE r.darjaSno = " . $darja . " AND regInfo.sno = r.stdSno  
														AND regInfo.sno = reg.regSno AND r.resultTerm = 3 AND 
														regInfo.sno = " . $regSno . " AND regInfo.isActive = 1  
														AND r.promotionDate = '" . $promotionDate . "'
													 	AND r.dateEnd = '" . $dateEnd . "'";
																//$resultMarks2 = mysql_query($subjectMarksSql2);

																if ($crud->search($subjectMarksSql2)) { //print_r($subjectMarksSql2);
																	$totalMarksInSubjects3 = 0;
																	$totalMarksIn3 = 0;
																	$aryCounter2 = -1;
																	foreach ($crud->getRecordSet($subjectMarksSql2) as $rowSub2) {
																		$aryCounter2 += 1;
																		//while($rowSub2 = mysql_fetch_assoc($resultMarks2)){  
																		$totalMarksIn3 += $rowSub2['obtmarks'];
																		$totalMarksInSubjects3 += $crud->getValue("SELECT s.totalMarks FROM subjects s WHERE s.sno = " . $rowSub2['subjectSno'], "totalMarks");

																		$sqlMarks3 = "SELECT obtmarks FROM result WHERE 
																				stdSno = '" . $regSno . "'
																				AND	darjaSno = " . $darja . " 
																				AND subjectsno = '" . $subject_ary[$aryCounter2] . "'
																				AND resultTerm = 3 
																				AND promotionDate = '" . $promotionDate . "'
													 							AND dateEnd = '" . $dateEnd . "'";
																		$obtN3 = $crud->getValue($sqlMarks3, "obtmarks");

																?>
															<td style="vertical-align:middle; text-align:center; <?php if ($obtN3 < 40) { ?> background-color:#CACACA; font-weight:bold; font-size:13px; <?php } ?>">
																<?php echo ($obtN3); ?> </td>
													<?php } //end while loop
																} //end if mysql_num_rows() 
													?>
												</tr>
											</table>
										</td>
										<td width="38" style="border-width:0px;">
											<table width="40" border="1" cellspacing="0" cellpadding="0">
												<tr style="border-width:0px;">
													<td> <?php echo ($totalMarksInSubjects1); ?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td> <?php echo ($totalMarksInSubjects2); ?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td> <?php echo ($totalMarksInSubjects3); ?> </td>
												</tr>
											</table>
										</td>
										<td width="41" style="border-width:0px;">
											<table width="40" border="1" cellspacing="0" cellpadding="0">
												<tr style="border-width:0px;">
													<td> <?php echo ($totalMarksIn1); ?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td>
														<?php echo ($totalMarksIn2); ?>
													</td>
												</tr>
												<tr style="border-width:0px;">
													<td>
														<?php echo ($totalMarksIn3); ?>
													</td>
												</tr>
											</table>
										</td>
										<td width="38" style="border-width:0px;">
											<table width="40" border="1" cellspacing="0" cellpadding="0">
												<tr style="border-width:0px;">
													<td> <?php echo (round((($totalMarksIn1 * 100) / $totalMarksInSubjects1), 2)); ?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td> <?php echo (round((($totalMarksIn2 * 100) / $totalMarksInSubjects2), 2)); ?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td> <?php echo (round((($totalMarksIn3 * 100) / $totalMarksInSubjects3), 2)); ?> </td>
												</tr>
											</table>
										</td>
										<td width="38" style="border-width:0px;">
											<table width="40" border="1" cellspacing="0" cellpadding="0">
												<tr style="border-width:0px;">
													<td> <?php //echo('('.$totalMarksIn1.'/'.$totalMarksInSubjects1.')* 100 < 40');
															if (($totalMarksIn1 / $totalMarksInSubjects1) * 100 < 40) {
																echo ("راسب");
															} else if (($totalMarksIn1 / $totalMarksInSubjects1) * 100 > 40 && ($totalMarksIn1 / $totalMarksInSubjects1) * 100 < 56) {
																echo ('مقبول');
															} else if (($totalMarksIn1 / $totalMarksInSubjects1) * 100 > 56 && ($totalMarksIn1 / $totalMarksInSubjects1) * 100 < 66) {
																echo ('جید');
															} else if (($totalMarksIn1 / $totalMarksInSubjects1) * 100 > 65 && ($totalMarksIn1 / $totalMarksInSubjects1) * 100 < 76) {
																echo ('جید جداً');
															} else if (($totalMarksIn1 / $totalMarksInSubjects1) * 100 > 75) {
																echo ('ممتاز');
															}
															?> </td>
												</tr>
												<tr style="border-width:0px;">
													<td>
														<?php //echo('('.$totalMarksIn1.'/'.$totalMarksInSubjects1.')* 100 < 40');
														if (($totalMarksIn2 / $totalMarksInSubjects2) * 100 < 40) {
															echo ("راسب");
														} else if (($totalMarksIn2 / $totalMarksInSubjects2) * 100 > 40 && ($totalMarksIn2 / $totalMarksInSubjects2) * 100 < 56) {
															echo ('مقبول');
														} else if (($totalMarksIn2 / $totalMarksInSubjects2) * 100 > 56 && ($totalMarksIn2 / $totalMarksInSubjects2) * 100 < 66) {
															echo ('جید');
														} else if (($totalMarksIn2 / $totalMarksInSubjects2) * 100 > 65 && ($totalMarksIn2 / $totalMarksInSubjects2) * 100 < 76) {
															echo ('جید جداً');
														} else if (($totalMarksIn2 / $totalMarksInSubjects2) * 100 > 75) {
															echo ('ممتاز');
														}
														?>
													</td>
												</tr>
												<tr style="border-width:0px;">
													<td>
														<?php //echo('('.$totalMarksIn1.'/'.$totalMarksInSubjects1.')* 100 < 40');
														if (($totalMarksIn3 / $totalMarksInSubjects3) * 100 < 40) {
															echo ("راسب");
														} else if (($totalMarksIn3 / $totalMarksInSubjects3) * 100 > 40 && ($totalMarksIn3 / $totalMarksInSubjects3) * 100 < 56) {
															echo ('مقبول');
														} else if (($totalMarksIn3 / $totalMarksInSubjects3) * 100 > 56 && ($totalMarksIn3 / $totalMarksInSubjects3) * 100 < 66) {
															echo ('جید');
														} else if (($totalMarksIn3 / $totalMarksInSubjects3) * 100 > 65 && ($totalMarksIn3 / $totalMarksInSubjects3) * 100 < 76) {
															echo ('جید جداً');
														} else if (($totalMarksIn3 / $totalMarksInSubjects3) * 100 > 75) {
															echo ('ممتاز');
														}
														?>
													</td>
												</tr>
											</table>
										</td>
										<?php $registrationNo = $crud->getValue("SELECT reg.registrationNo FROM regnumbers reg,registrationinfo r WHERE reg.regSno = r.sno AND reg.regSno =" . $regSno, "registrationNo");
										$obtMarksSum1Sql = "SELECT SUM(obtmarks) AS total FROM result 
														WHERE resultTerm = 1 AND 
														stdSno = '" . $regSno . "' AND 
														promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "' 
														AND darjaSno = " . $darja;
										/*echo($obtMarksSum1Sql);
														exit();*/
										$mrks1 = $crud->getValue($obtMarksSum1Sql, "total");
										//echo($mrks1);
										$stdNameSqlA = "SELECT CONCAT(r.stdName,' ولدِ ',r.fatherName) as stdName 
																		FROM registrationinfo r, result reg, regnumbers rr
																		WHERE r.sno = reg.stdSno AND r.isActive = 1 AND reg.promotionDate = '" . $promotionDate . "' AND reg.dateEnd = '" . $dateEnd . "' 
																		AND r.sno = " . $regSno . " AND reg.stdSno = r.sno LIMIT 1";
										$stdNameA = $crud->getValue($stdNameSqlA, "stdName");

										$obtMarksSum2Sql = "SELECT SUM(obtmarks) AS total FROM result 
														WHERE resultTerm = 2 AND 
														stdSno = '" . $regSno . "' AND 
														promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "' AND darjaSno = " . $darja;
										//echo($obtMarksSum2Sql);
										$stdNameSqlB = "SELECT CONCAT(r.stdName,' ولدِ ',r.fatherName) as stdName 
																		FROM registrationinfo r, result reg, regnumbers rr
																		WHERE r.sno = reg.stdSno AND reg.promotionDate = '" . $promotionDate . "' AND reg.dateEnd = '" . $dateEnd . "' 
																		AND r.sno = " . $regSno . " AND r.isActive = 1 AND reg.stdSno = r.sno LIMIT 1";
										$stdNameB = $crud->getValue($stdNameSqlB, "stdName");
										$mrks2 = $crud->getValue($obtMarksSum2Sql, "total");
										$obtMarksSum3Sql = "SELECT SUM(obtmarks) AS total FROM result 
														WHERE resultTerm ='3' AND 
														stdSno = '" . $regSno . "' AND 
														promotionDate = '" . $promotionDate . "' AND dateEnd = '" . $dateEnd . "' AND darjaSno = " . $darja;
										//echo($obtMarksSum3Sql);
										$stdNameSqlC = "SELECT CONCAT(r.stdName,' ولدِ ',r.fatherName) as stdName 
																		FROM registrationinfo r, result reg, regnumbers rr
																		WHERE r.sno = rr.regSno AND reg.promotionDate = '" . $promotionDate . "' AND reg.dateEnd = '" . $dateEnd . "' 
																		AND r.sno = " . $regSno . " AND r.isActive = 1 AND reg.stdSno = r.sno LIMIT 1";
										$stdNameC = $crud->getValue($stdNameSqlC, "stdName");
										$mrks3 = $crud->getValue($obtMarksSum3Sql, "total");
										?>
										<td width="59" style="text-align:left; border-width:0px;">
											<table width="100%" border="1" cellpadding="0" cellspacing="0">
												<tr style="border-width:0px;">
													<td width="67" nowrap="nowrap" class="atten" style="vertical-align:middle; text-align:center;font-size:16px; height:20px; line-height:14px; font-weight:bold;"> غیر حاضری </td>
												</tr>
												<tr style="border-width:0px;">
													<td class="atten" style="vertical-align:middle; text-align:center; height:20px; line-height:14px;"> رخصت </td>
												</tr>
												<tr style="border-width:0px;">
													<td class="atten" style="vertical-align:middle; text-align:center; height:20px; line-height:14px;"> بیمار </td>
												</tr>
											</table>
										</td>
										<td style="border-width:0px;">
											<table width="350" border="0" cellspacing="0" cellpadding="0" style="border-width:0px;">
												<tr style="border-width:0px;">
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSql =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '10' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'غ'";
																	$v1 = $crud->getValue($hSql, "total");
																	if ($v1 != 0) {
																		echo ($v2);
																		$mezaan1 += $v1;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq2 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '10' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ر'";
																	$v2 = $crud->getValue($hSq2, "total");
																	if ($v2 != 0) {
																		echo ($v2);
																		$mezaan2 += $v2;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq3 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '10' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ب'";
																	$v3 = $crud->getValue($hSq3, "total");
																	if ($v3 != 0) {
																		echo ($v3);
																		$mezaan3 += $v3;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq4 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '11' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'غ'";
																	$v4 = $crud->getValue($hSq4, "total");
																	if (!empty($v4)) {
																		echo ($v4);
																		$mezaan1 += $v4;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq5 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '11' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ر'";
																	$v5 += $crud->getValue($hSq5, "total");
																	if (!empty($v5)) {
																		echo ($v5);
																		$mezaan2 += $v5;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq6 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '11' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ب'";
																	$v6 = $crud->getValue($hSq6, "total");
																	if (!empty($v6)) {
																		echo ($v6);
																		$mezaan3 += $v6;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq7 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '12' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'غ'";
																	$v7 = $crud->getValue($hSq7, "total");
																	if (!empty($v7)) {
																		echo ($v7);
																		$mezaan1 += $v7;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq8 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '12' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ر'";
																	$v8 = $crud->getValue($hSq8, "total");
																	if (!empty($v8)) {
																		echo ($v8);
																		$mezaan2 += $v8;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq9 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                      AND MONTH(attendanceDate) = '12' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                      AND stdStatus = 'ب'";
																	$v9 = $crud->getValue($hSq9, "total");
																	if (!empty($v9)) {
																		echo ($v9);
																		$mezaan3 += $v9;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSql_9 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '01' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v_9 = $crud->getValue($hSql_9, "total");
																	if (!empty($v9)) {
																		echo ($v_9);
																		$mezaan1 += $v_9;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq10 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '01' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v10 = $crud->getValue($hSq10, "total");
																	if (!empty($v10)) {
																		echo ($v10);
																		$mezaan2 += $v10;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq11 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '01' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v11 = $crud->getValue($hSq11, "total");
																	if (!empty($v11)) {
																		echo ($v11);
																		$mezaan3 += $v11;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq12 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '02' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v12 = $crud->getValue($hSq12, "total");
																	if (!empty($v12)) {
																		echo ($v12);
																		$mezaan1 += $v12;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq13 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '02' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v13 = $crud->getValue($hSq13, "total");
																	if (!empty($v13)) {
																		echo ($v13);
																		$mezaan2 += $v13;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq14 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '02' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v14 = $crud->getValue($hSq14, "total");
																	if (!empty($v14)) {
																		echo ($v14);
																		$mezaan3 += $v14;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq15 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '03' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v15 = $crud->getValue($hSq15, "total");
																	if (!empty($v15)) {
																		echo ($v15);
																		$mezaan1 += $v15;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq16 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '03' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v16 = $crud->getValue($hSq16, "total");
																	if (!empty($v16)) {
																		echo ($v16);
																		$mezaan2 += $v16;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq17 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '03' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v17 = $crud->getValue($hSq17, "total");
																	if (!empty($v17)) {
																		echo ($v17);
																		$mezaan3 += $v17;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq18 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '04' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v18 = $crud->getValue($hSq18, "total");
																	if (!empty($v18)) {
																		echo ($v18);
																		$mezaan1 += $v18;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq19 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '04' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v19 = $crud->getValue($hSq19, "total");
																	if (!empty($v19)) {
																		echo ($v19);
																		$mezaan2 += $v19;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq20 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '04' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v20 = $crud->getValue($hSq20, "total");
																	if (!empty($v20)) {
																		echo ($v20);
																		$mezaan3 += $v20;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq21 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '05' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v21 = $crud->getValue($hSq21, "total");
																	if (!empty($v21)) {
																		echo ($v21);
																		$mezaan1 += $v21;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq22 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '05' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v22 = $crud->getValue($hSq22, "total");
																	if (!empty($v22)) {
																		echo ($v22);
																		$mezaan2 += $v22;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq23 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '05' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v23 = $crud->getValue($hSq23, "total");
																	if (!empty($v23)) {
																		echo ($v23);
																		$mezaan3 += $v23;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq24 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '06' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v24 = $crud->getValue($hSq24, "total");
																	if (!empty($v24)) {
																		echo ($v24);
																		$mezaan1 += $v24;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq25 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '06' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v25 = $crud->getValue($hSq25, "total");
																	if (!empty($v25)) {
																		echo ($v25);
																		$mezaan2 += $v25;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq26 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '06' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v26 = $crud->getValue($hSq26, "total");
																	if (!empty($v26)) {
																		echo ($v26);
																		$mezaan3 += $v26;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
													<td width="45" style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq24 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '07' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'غ'";
																	$v24 = $crud->getValue($hSq24, "total");
																	if (!empty($v24)) {
																		echo ($v24);
																		$mezaan1 += $v24;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq25 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '07' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ر'";
																	$v25 = $crud->getValue($hSq25, "total");
																	if (!empty($v25)) {
																		echo ($v25);
																		$mezaan2 += $v25;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
															<tr style="border-width:0px;">
																<td style="vertical-align:middle; text-align:center;">
																	<?php
																	$hSq26 =  "SELECT COUNT(stdStatus) AS total FROM attendence WHERE YEAR(attendanceDate) = YEAR(" . $promotionDate . ")
                                                          AND MONTH(attendanceDate) = '07' AND darjaSno = " . $darja . " AND regSno = " . $regSno . " 
                                                          AND stdStatus = 'ب'";
																	$v26 = $crud->getValue($hSq26, "total");
																	if (!empty($v26)) {
																		echo ($v26);
																		$mezaan3 += $v26;
																	} else {
																		echo ('-');
																	}
																	?>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
										<td style="border-width:0px;">
											<table width="156" border="1" cellspacing="0" cellpadding="0">
												<tr>
													<td style="border-width:0px;">
														<table width="100%" border="1" cellspacing="0" cellpadding="0">
															<tr>
																<td style="height:6px;"> <?php if ((empty($mezaan1) || $mezaan1 < 1) && (empty($mezaan2) || $mezaan2 < 1) && (empty($mezaan3) || $mezaan3 < 1)) {
																								echo ('صاحب ترتیب');
																							} else {
																								echo ('&nbsp;');
																							}
																							?>
																</td>
															</tr>
															<tr>
																<td style="height:6px;"> <?php if ((empty($mezaan1) || $mezaan1 < 1) && (empty($mezaan2) || $mezaan2 < 1) && (empty($mezaan3) || $mezaan3 < 1)) {
																								echo ('صاحب ترتیب');
																							} else {
																								echo ('&nbsp;');
																							}

																							?>
																</td>
															</tr>
															<tr>
																<td nowrap="nowrap" style="height:6px;"> <?php if ((empty($mezaan1) || $mezaan1 < 1) && (empty($mezaan2) || $mezaan2 < 1) && (empty($mezaan3) || $mezaan3 < 1)) {
																												echo ('صاحب ترتیب');
																											} else {
																												echo ('&nbsp;');
																											}

																											?>
																</td>
															</tr>
														</table>
													</td>
													<td width="66" align="left" style="border-width:0px;">
														<table width="100%" border="0" cellspacing="0" cellpadding="0">
															<tr style="border-width:0px;">
																<td style="text-align:center"> <?php
																								$imgStd = $crud->getValue("SELECT stdPhoto FROM registrationinfo WHERE sno = " . $regSno, "stdPhoto");
																								if (isset($imgStd) && !empty($imgStd)) {
																								?>
																		<img src="../takephoto/<?php echo ($imgStd); ?>" style="border-width:0px; height:65px; width:60px;" hspace="1" vspace="1" />
																	<?php } ?>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
							<?php } //end loop $resultStd
							} //end if no record found by $resultStd
							?>
						</table>
			<?php
					} //if the result was uploaded on the spesific year 
					else {
						//no result was found on specified year
						echo ($crud->errorMsg("مہیاں کردہ سال میں کوئی بھی نتیجہ نہیں بنایا گیا ہے۔", "غلطی", "../images"));
					}
				} //end if for year and darja fields empty check
				else {
					echo ($crud->errorMsg("مہربانی کر کے درجہ، طالب العلم اور تاریخ کی باکس میں صحیح معلومات ڈالیں۔", "غلطی", "../images"));
				} //end else for year , darja  and std Name fields empty check
			} //end if for btnSearch
			?>
		</div>
		<br /><br />
	</center>
	<script language="javascript">
		var nVer = navigator.appVersion;
		var nAgt = navigator.userAgent;
		var broName = navigator.appName;
		/*var fullVersion  = ''+parseFloat(navigator.appVersion); 
		var majorVersion = parseInt(navigator.appVersion,10);*/
		var nameOffset, verOffset, ix;

		// In Chrome, the true version is after "Chrome" 
		if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
			broName = "Chrome";
			if (broName == "Chrome") {
				$("#mont").css("height", "62px");
				$(".session").css("height", "22px");
				$(".atten").css("height", "22px");
			}
		}
	</script>
</body>

</html>