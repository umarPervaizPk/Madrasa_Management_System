<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>قانونی استعمال اور اجازت برائے سافٹ وئیر ہٰذا </title>
    <link rel="stylesheet" type="text/css" href="../css/default.css" />
    <style>
        #contentsTbl {
            font-size: 22px;
        }
    </style>
</head>

<body style="background-image:none; background-color:#ffffff;">
    <center>
        <div id="printerArea" style="width:1020px; background-color:#ffffff;">
            <table width="800" align="center" border="1" cellspacing="0" cellpadding="4">
                </tr>
                <tr>
                    <td style="text-align:justify !important;">
                        <div id="contentTitle" class="titleFont" style="text-align:justify; font-size:30px;">
                            باقاعدہ اجازت نامہ و استعمال سافٹ وئیر ھٰذا برائے مدرسہ و دیگر تعلیمی و غیر تعلیمی ادارہ جات
                            <div style="height:15px;">
                                <hr />
                            </div>
                            <table width="100%" border="0" cellpadding="3" cellspacing="0" id="contentsTbl">
                                <tr>
                                    <td>برائے مہربانی مندرجہ ذیل کو بہت غور و احتیاط کے ساتھ پڑھ لیجئے۔ </td>
                                </tr>
                                <tr>
                                    <td>
                                        <ol type="1">
                                            <li> سافٹ وئیر کا نام "مدرسہ منیجمینٹ سسٹم (Madrasa Management System)" ہے۔ </li>
                                            <li> (Software Vendor) سافٹ وئیر ونڈر: شاہ حسین سافٹ وئیر انجینیر </li>
                                            <li> اس سافٹ وئیر کے تمام اجزاء (Components) بحق سافٹ وئیر بنانے والے (Software Vendor) کے بذریعہ سرکار
                                                جملہ حقوق محفوظ ہیں۔ لھٰذا خلاف ورزی کرنے والوں کے خلاف کاپی رائیٹ ایکٹ کے تحت سخت قانونی کاروائی کی جائیگی۔ </li>
                                            <li> سافٹ وئیر "مدرسہ منیجمینٹ سسٹم" کو باقاعدہ تحریری اجازت نامے کے تحت فروخت کیا جاتا ہے۔ </li>
                                            <li> اگر کسی بھی ادارہ/سکول/مدرسہ یا اس کے علاوہ کسی بھی دیگر شخص کے پاس یہ سافٹ وئیر یا اس سافٹ وئیر
                                                کا کوئ بھی حصہ ملا یا بر آمد ہوا تو اس کے خلاف باقاعدہ قانونی چارہ جوئی کی جائیگی جس کے تحت وہ ادارہ
                                                یا شخص مندرجہ ذیل سزا کا جس کا اطلاق باقاعدہ حکومت پاکستان اور بین الاقوامی ادارہ جات برائے تحّفظات
                                                کمپیوٹر سافٹ وئیر یا اس قسم کی دیگر کمپیوٹر پروگرامز کی تحفظات کے لئے کام کرتے ہیں، کا حقدار ہوگا۔
                                                <ul>
                                                    <li> <strong>سزا۔</strong></li>
                                                    <li> کم از کم 4 سال قید اور ساتھ ہی ساتھ تین (3) لاکھ روپے نقد جرمانہ جو کہ بحق
                                                        سافٹ وئیر ڈیویلپر (Software Developer/Vendor) بذریعہ سرکار حاصل کر کے جمع کی جائیگی۔</li>
                                                </ul>
                                            </li>
                                            <li> سافٹ وئیر کو چلانے کے لئے کسی بھی قسم کی (Maintenance) کی اگر ضرورت ہو تو باقاعدہ طور پر
                                                سافٹ وئیر ونڈر سے رابطہ کیا جایئگا جس پر اس سافٹ وئیر کو بنانے والا (Vendor) ہی کام کریگا بصورت دیگر
                                                سافٹ وئیر ونڈر اور (Maintenance) کرنے والوں کے مابین اگر تحریری طور پر اجازت نامہ مل جانے کے صورت
                                                میں ہی کوئی دوسرا پروگرامر یا سافٹ وئیر انجینیر یا کوئ دیگر شخص کام کر سکتا ہے اور وہ بھی اسی سکرپٹ/ پروگرام کے حصہ
                                                کے اندر جس کا اجازت باقاعدہ طور پر مندرجہ بالا طریقہ ہائے کے طور پر مل گئ ہو تب۔ ورنہ وہ ادارہ
                                                یا شخص مندرجہ بالا سزا کا
                                                باقاعدہ طور پر حقدار ہوگا۔</li>
                                            <li> اس حقوق (Copy Rights) کو ہٹانا بھی جرم ہے اور اس حقوق کو اس سافٹ وئیر سے ہٹانے والا بھی
                                                جرم کا مرتکب ہوگا جس پر باقاعدہ طور پر مندرجہ بالا سزا کا اطلاق ہوگا۔ </li>
                                            <li> اگر آپ سافٹ وئیر ھٰذا کو استعمال کرنے / خریدنے کرنے کے خواہشمند ہیں تو آپ کو اِن تمام امور
                                                کی سختی سے پابندی کرنے پڑیگی بصورت دیگر آپ اس سافٹ وئیر کو استعمال کرنے کے اہل نہ ہونگے۔ </li>
                                        </ol>
                                        <font style="font-size:30px;"> حلف نامہ۔</font><br />
                                        میں نے اوپر کے تمام امور کا بڑی غور سے مطالعہ کیا اور میں اس سافٹ وئیر کو استعمال کرنا چاہتاں /چاہتی ہوں
                                        اور میں اس ڈاکومنٹ پر دستخط کر کے یہ اقرار کرتا / کرتی ہوں کہ میں ان ہدایات پر بڑی سختی سے عمل کرونگا/کرونگی
                                        بصورت دیگر مجھ پر اِن تمام امور کا باقاعدہ طور پر اطلاق ہوگا اور میں اس کا پابند ہونگا کہ یہ سزا بغیر کسی ہچکچاہٹ
                                        کے قبول کروں۔
                                        <br /><br />
                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                            <tr>
                                                <td width="72%" style="vertical-align:top;">
                                                    <font style="font-size:30px;"> (استعمال کنندہ) </font><br />
                                                    نام۔ <?php require_once('../classes/classes.php');
                                                            $crud = new CRUD();
                                                            $ownerName = $crud->getValue("SELECT ownreName FROM login ORDER BY sno ASC LIMIT 1", "ownreName");
                                                            echo ($ownerName);
                                                            ?>
                                                    <br />
                                                    دستخط۔ <?php echo ($ownerName); ?>
                                                    <br />
                                                    تاریخ: - 2012-01-01
                                                </td>
                                                <td width="28%" style="vertical-align:top;">
                                                    <font style="font-size:30px;"> (سافٹ وئیر ونڈر) </font> <br />
                                                    نام۔ شاہ حسین <br />
                                                    دستخط
                                                    <br /> موبائیل نمبر 03139419449
                                                </td>
                                            </tr>
                                        </table>


                                    </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
            <br />
        </div>
    </center>
</body>

</html>